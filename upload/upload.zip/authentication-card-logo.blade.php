<a href="/">
    <img src="{{ asset('asset/logo_warna_bulat.png') }}" class="w-24" alt="syariah saham">
</a>
